# Pardhan Player v3 — Build Notes
Package: com.pardhancodes.pardhanplayer  (POWERED BY PARDHANCODE)
Gradle 8.9, AGP 8.7.2, JDK 17, SDK 35.  Build: gradle assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk

Screens: Home (resume + tiles), Videos, Music, Folders (Internal/SD), Settings, Equalizer, Private Vault (PIN + biometric).
Not yet: thumbnails, frame-by-frame, external subtitle files, swipe gestures, FFmpeg audio (AC3/DTS).
