# Pardhan Player — Build Notes
Package: com.pardhancodes.pardhanplayer  (POWERED BY PARDHANCODE)

1. Project ko Android Studio / AndroidIDE mein open karein (Gradle 8.9, AGP 8.7.2, JDK 17, SDK 35).
2. Debug APK:  ./gradlew assembleDebug   (wrapper jar na ho to IDE khud bana deta hai)
3. APK: app/build/outputs/apk/debug/app-debug.apk

Features: video/audio list (MediaStore), ExoPlayer + MediaSession service (background audio),
speed/subtitle/audio-track menu (PlayerView settings), PiP, external file/stream open,
biometric Private Vault (encrypted import + playback).

Known limits: FFmpeg audio decoder (AC3/DTS MKV) nahi hai; vault play karte waqt temp decrypted
copy cache mein rehti hai (app band hone par delete); gesture controls (brightness/volume swipe) abhi nahi.
