package com.pardhancodes.pardhanplayer

import android.Manifest
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.google.common.util.concurrent.ListenableFuture
import com.pardhancodes.pardhanplayer.service.PardhanPlaybackService
import com.pardhancodes.pardhanplayer.vault.PrivateVaultManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : FragmentActivity() {

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val controller = mutableStateOf<MediaController?>(null)
    private val pendingUri = mutableStateOf<Uri?>(null)
    private val inPlayer = mutableStateOf(false)
    private val vaultUnlocked = mutableStateOf(false)
    private var pickingFile = false
    private val vault by lazy { PrivateVaultManager(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingUri.value = intent?.data

        val token = SessionToken(this, ComponentName(this, PardhanPlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener(
            { runCatching { controller.value = future.get() } },
            ContextCompat.getMainExecutor(this)
        )

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Color(0xFF000000),
                    surface = Color(0xFF090A10),
                    primary = Color(0xFF3B82F6),
                    secondary = Color(0xFF8B5CF6)
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize()) { PardhanApp() }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingUri.value = intent.data
    }

    override fun onStop() {
        super.onStop()
        if (!pickingFile && !isInPictureInPictureMode) vaultUnlocked.value = false
    }

    override fun onUserLeaveHint() {
        val c = controller.value
        if (inPlayer.value && c != null && c.isPlaying && c.videoSize.width > 0) {
            enterVideoPip(c.videoSize.width, c.videoSize.height)
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        if (isFinishing) vault.clearTemp()
        super.onDestroy()
    }

    fun enterVideoPip(width: Int, height: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ratio = Rational(width.coerceAtLeast(1), height.coerceAtLeast(1))
            runCatching {
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ratio).build())
            }
        }
    }

    // ---------- permissions ----------
    private fun mediaPerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun requestPerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) mediaPerms() + Manifest.permission.POST_NOTIFICATIONS
        else mediaPerms()

    private fun hasMediaPerms() = mediaPerms().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    // ---------- playback ----------
    private fun playItems(items: List<MediaItem>, index: Int) {
        val c = controller.value ?: run {
            Toast.makeText(this, "Player starting, try again", Toast.LENGTH_SHORT).show(); return
        }
        c.setMediaItems(items, index, 0L)
        c.prepare()
        c.play()
        inPlayer.value = true
    }

    // ---------- UI ----------
    @Composable
    private fun PardhanApp() {
        val scope = rememberCoroutineScope()
        var granted by remember { mutableStateOf(hasMediaPerms()) }
        val permLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { granted = hasMediaPerms() }
        LaunchedEffect(Unit) { if (!granted) permLauncher.launch(requestPerms()) }

        var tab by remember { mutableIntStateOf(0) }
        var videos by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }
        var audios by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }
        LaunchedEffect(granted) {
            if (granted) {
                videos = withContext(Dispatchers.IO) { MediaScanner.scan(this@MainActivity, true) }
                audios = withContext(Dispatchers.IO) { MediaScanner.scan(this@MainActivity, false) }
            }
        }

        // Media opened from other apps / links
        val pending = pendingUri.value
        val c = controller.value
        LaunchedEffect(pending, c) {
            if (pending != null && c != null) {
                playItems(listOf(MediaItem.fromUri(pending)), 0)
                pendingUri.value = null
            }
        }

        if (inPlayer.value && c != null) {
            PlayerScreen(c) {
                if (c.videoSize.width > 0) c.pause()
                inPlayer.value = false
            }
            return
        }

        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.VideoLibrary, null) }, label = { Text("Videos") })
                    NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.MusicNote, null) }, label = { Text("Audio") })
                    NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.Lock, null) }, label = { Text("Vault") })
                }
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                Text(
                    "Pardhan Player",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 0.dp)
                )
                Text(
                    "Powered by PardhanCode",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(16.dp, 0.dp, 16.dp, 8.dp)
                )
                when {
                    tab == 2 -> VaultTab()
                    !granted -> Column(Modifier.padding(16.dp)) {
                        Text("Media permission chahiye videos/audio dikhane ke liye.")
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { permLauncher.launch(requestPerms()) }) { Text("Allow") }
                    }
                    else -> MediaList(if (tab == 0) videos else audios) { list, i ->
                        playItems(list.map { it.toItem() }, i)
                    }
                }
            }
        }
    }

    @Composable
    private fun MediaList(list: List<MediaEntry>, onPlay: (List<MediaEntry>, Int) -> Unit) {
        if (list.isEmpty()) {
            Text("Koi file nahi mili.", Modifier.padding(16.dp)); return
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(list.size) { i ->
                val e = list[i]
                Row(
                    Modifier.fillMaxWidth().clickable { onPlay(list, i) }.padding(16.dp, 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.PlayArrow, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.title, maxLines = 2)
                        Text(fmt(e.durationMs), style = MaterialTheme.typography.labelSmall)
                    }
                }
                HorizontalDivider()
            }
        }
    }

    @Composable
    private fun VaultTab() {
        val scope = rememberCoroutineScope()
        var refresh by remember { mutableIntStateOf(0) }
        val unlocked = vaultUnlocked.value

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            pickingFile = false
            if (uri != null) scope.launch {
                withContext(Dispatchers.IO) { runCatching { vault.importUri(uri) } }
                refresh++
                Toast.makeText(this@MainActivity, "Vault mein add ho gaya (original khud delete karein)", Toast.LENGTH_LONG).show()
            }
        }

        if (!unlocked) {
            Column(Modifier.padding(16.dp)) {
                Text("Private Vault locked hai.")
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    vault.authenticateBiometric(
                        this@MainActivity,
                        onSuccess = { vaultUnlocked.value = true },
                        onError = { Toast.makeText(this@MainActivity, it, Toast.LENGTH_SHORT).show() }
                    )
                }) { Text("Unlock") }
            }
            return
        }

        val files = remember(refresh) { vault.listVaultFiles() }
        Column(Modifier.fillMaxSize()) {
            Button(
                onClick = { pickingFile = true; picker.launch(arrayOf("video/*", "audio/*")) },
                modifier = Modifier.padding(16.dp, 0.dp)
            ) { Text("Add file to Vault") }
            if (files.isEmpty()) Text("Vault khali hai.", Modifier.padding(16.dp))
            LazyColumn {
                items(files.size) { i ->
                    val f = files[i]
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            scope.launch {
                                val plain: File? = withContext(Dispatchers.IO) {
                                    runCatching { vault.decryptToCache(f) }.getOrNull()
                                }
                                if (plain != null) playItems(listOf(MediaItem.fromUri(Uri.fromFile(plain))), 0)
                                else Toast.makeText(this@MainActivity, "Decrypt fail", Toast.LENGTH_SHORT).show()
                            }
                        }.padding(16.dp, 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(12.dp))
                        Text(f.name.removeSuffix(".pvault"), maxLines = 2)
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    @Composable
    private fun PlayerScreen(player: Player, onBack: () -> Unit) {
        BackHandler(onBack = onBack)
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = true
                    controllerShowTimeoutMs = 3000
                    setShowNextButton(true)
                    setShowPreviousButton(true)
                }
            },
            onRelease = { it.player = null }
        )
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }
}
